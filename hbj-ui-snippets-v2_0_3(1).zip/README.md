# HBJ UI Snippets v2.0.3 — Add “Contact Us” Button (Last)

This bundle gives you **drop‑in HTML** to add a high‑contrast **Contact Us** button
as the **last button** in your top row. It opens your store’s contact page in a new tab
and avoids link rewriting (uses a form-based CTA).

## Files
- `snippets/contact_us_button.html` — single Contact Us button (place it last).
- `snippets/contact_us_button_with_beacon.html` — same button, also logs the action to your bot via `sendBeacon` (optional).
- `snippets/top_buttons_row.html` — an example of the full row with your existing four buttons **plus** Contact Us at the end.
  - Buttons in order: **Find a kit**, **Sterilized Jewelry**, **Aftercare**, **Shipping & Returns**, **Contact Us** (last).
  - Uses form‑based CTAs for store pages so hosts can’t rewrite links.
  - The **Find a kit** button is a regular `<button>` and will call your existing chat handler if available.
    If your site exposes `window.hbjSend(q)`, it will use it. Otherwise it dispatches a `CustomEvent('hbj:query', {detail:{q}})`.

## How to install
1. In your page/template where the four buttons live, paste the contents of **`contact_us_button.html`** **after** your existing buttons (so it’s last).
   - Or replace the entire block with **`top_buttons_row.html`** if you prefer.
2. Hard refresh your site (Shift + Reload).

## Quick test
- Click **Contact Us** → should open: `https://www.hottiebodyjewelry.com/crm.asp?action=contactus` in a new tab.
- Right‑click the Contact button → **Copy link address** → it must be that full URL. If it isn’t, your page is cached; hard refresh.

## Notes
- All buttons use inline styles with `!important` to stay readable (your theme can’t force brown/low‑contrast).
- No backend changes required.
