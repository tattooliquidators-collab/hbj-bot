# HBJ UI Contact Button Patch v2.0.4

You’re seeing 4 buttons (Find a kit, Sterilized jewelry, Aftercare, Shipping & returns).
This patch gives you **three ways** to add a **Contact Us** button **last** in that row.

## Files
- `snippets/contact_us_button.html` — paste this **after** your current four buttons.
- `snippets/top_buttons_row_5.html` — full replacement block with all five buttons, Contact last.
- `public/contact_inject.js` — **auto‑append** Contact button with JavaScript if you can’t find the HTML.
- `README.md` — these instructions.

## Option A — Quick paste (recommended)
1) Open the template/page where the four buttons live.
2) Paste the contents of `snippets/contact_us_button.html` **after** the existing buttons.
3) Save and hard‑refresh your site (Shift + Reload).

## Option B — Replace the whole row
1) Replace your existing button block with the contents of `snippets/top_buttons_row_5.html`.
2) Save and hard‑refresh.

## Option C — Auto‑append with JS (no template edits)
1) Upload `public/contact_inject.js` to your repo and ensure it is served on the assistant page.
2) Include it with:
   ```html
   <script src="/contact_inject.js" defer></script>
   ```
   (If your site serves assets from another path, adjust the src accordingly.)
3) It will find the **Shipping & returns** button and insert **Contact Us** **after** it. If it can’t find it, it appends at the end of the same container.

## Test
- Click **Contact Us** → opens `https://www.hottiebodyjewelry.com/crm.asp?action=contactus` in a new tab.
- Right‑click → **Copy link address** should show that exact URL.
- In chat, type **contact** → your backend (v2.0.2) returns the Contact CTA; make sure your UI renders with `innerHTML` (not `textContent`).

