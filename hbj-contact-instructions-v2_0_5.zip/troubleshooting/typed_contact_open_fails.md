# If typing “contact” doesn’t show the CTA

Your backend returns HTML for the contact block, but your front-end might be inserting it
as text. Fix the render line in your chat code:

```js
// WRONG (strips HTML)
replyEl.textContent = data.html;

// RIGHT
replyEl.innerHTML = data.html;   // render forms/buttons
```

### Quick diagnostics
1) Open: `https://hbj-bot.onrender.com/hbj/health` → expect `"version":"2.0.2"` (or higher).
2) Open: `https://hbj-bot.onrender.com/hbj/intent?q=contact` → expect `{"intent":"contact"}`.
3) In the browser console, run:
```js
fetch('https://hbj-bot.onrender.com/hbj/chat', {
  method:'POST',
  headers:{'content-type':'application/json'},
  body: JSON.stringify({ q:'contact us' })
}).then(r=>r.json()).then(x=>console.log(x.html));
```
You should see HTML with a big **Open Contact Page** button.
If you do, but your UI shows nothing, switch to `innerHTML` above.
