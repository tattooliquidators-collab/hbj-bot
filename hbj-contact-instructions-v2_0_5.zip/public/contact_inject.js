/* contact_inject.js — append Contact Us button last */
(function(){
  function ready(fn){document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn);}
  ready(function(){
    try {
      var btns = Array.from(document.querySelectorAll('button, form button'));
      var ship = btns.find(function(b){ return /shipping/i.test((b.textContent||'').trim()); });
      var container = ship ? ship.closest('div,section,nav,footer,header') : (btns[0] && btns[0].parentElement);
      if (!container) return;
      if (container.querySelector('[data-hbj-contact]')) return; // avoid duplicates
      var f = document.createElement('form');
      f.action = 'https://www.hottiebodyjewelry.com/crm.asp?action=contactus';
      f.method = 'GET'; f.target = '_blank'; f.style.display = 'inline';
      var b = document.createElement('button'); b.type='submit'; b.textContent='Contact Us'; b.setAttribute('data-hbj-contact','1');
      b.style.cssText='background:#0b5fff!important;color:#fff!important;padding:10px 14px;border-radius:10px;font-weight:900!important;border:0;cursor:pointer';
      f.appendChild(b);
      if (ship && ship.parentElement) {
        ship.parentElement.insertAdjacentElement('afterend', f);
      } else {
        container.appendChild(f);
      }
    } catch(e){ console && console.warn && console.warn('HBJ contact inject failed', e); }
  });
})();
